'use client';

import { useState } from 'react';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';
import * as ExcelJS from 'exceljs';
import { format } from 'date-fns';
import { nb } from 'date-fns/locale';

export default function ExportTimeButton() {
  const [isExporting, setIsExporting] = useState(false);
  const supabase = createClientComponentClient();

  const exportToExcel = async () => {
    setIsExporting(true);
    try {
      // Hent timeregistreringer
      const { data: timeEntries } = await supabase
        .from('time_entries')
        .select(`
          *,
          customers (name),
          employees (name),
          tasks (title)
        `)
        .order('start_time', { ascending: false });

      if (!timeEntries) return;

      // Opprett Excel-arbeidsbok
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Timeregistreringer');

      // Definer kolonner
      worksheet.columns = [
        { header: 'Dato', key: 'date', width: 12 },
        { header: 'Kunde', key: 'customer', width: 30 },
        { header: 'Ansatt', key: 'employee', width: 20 },
        { header: 'Oppgave', key: 'task', width: 20 },
        { header: 'Beskrivelse', key: 'description', width: 40 },
        { header: 'Start', key: 'start', width: 10 },
        { header: 'Slutt', key: 'end', width: 10 },
        { header: 'Timer', key: 'hours', width: 10 },
      ];

      // Legg til data
      timeEntries.forEach(entry => {
        const startTime = new Date(entry.start_time);
        const endTime = new Date(entry.end_time);
        const duration = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60); // timer

        worksheet.addRow({
          date: format(startTime, 'dd.MM.yyyy', { locale: nb }),
          customer: entry.customers?.name || '',
          employee: entry.employees?.name || '',
          task: entry.tasks?.title || '',
          description: entry.description,
          start: format(startTime, 'HH:mm', { locale: nb }),
          end: format(endTime, 'HH:mm', { locale: nb }),
          hours: duration.toFixed(2),
        });
      });

      // Style header
      worksheet.getRow(1).font = { bold: true };
      worksheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFE0E0E0' }
      };

      // Generer fil
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = window.URL.createObjectURL(blob);
      
      // Last ned fil
      const a = document.createElement('a');
      a.href = url;
      a.download = `timeregistreringer_${format(new Date(), 'yyyy-MM-dd')}.xlsx`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Feil ved eksport:', error);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <button
      onClick={exportToExcel}
      disabled={isExporting}
      className="btn-primary"
    >
      {isExporting ? 'Eksporterer...' : 'Eksporter til Excel'}
    </button>
  );
}