'use client';

import { useState, useEffect } from 'react';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';
import { useRouter } from 'next/navigation';
import { Customer, Task, Employee } from '@/lib/api/types';

interface TimeTrackerProps {
  customerId?: string;
  taskId?: string;
}

export default function TimeTracker({ customerId, taskId }: TimeTrackerProps) {
  const [isTracking, setIsTracking] = useState(false);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [description, setDescription] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState(customerId || '');
  const [selectedTask, setSelectedTask] = useState(taskId || '');
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [employee, setEmployee] = useState<Employee | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const router = useRouter();
  const supabase = createClientComponentClient();

  useEffect(() => {
    async function loadData() {
      // Load customers
      const { data: customersData } = await supabase
        .from('customers')
        .select('*')
        .order('name');
      
      if (customersData) {
        setCustomers(customersData);
      }

      // Load employee info
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: employeeData } = await supabase
          .from('employees')
          .select('*')
          .eq('user_id', user.id)
          .single();
        
        if (employeeData) {
          setEmployee(employeeData);
        }
      }
    }

    loadData();
  }, [supabase]);

  useEffect(() => {
    async function loadTasks() {
      if (selectedCustomer) {
        const { data: tasksData } = await supabase
          .from('tasks')
          .select('*')
          .eq('customer_id', selectedCustomer)
          .order('due_date');
        
        if (tasksData) {
          setTasks(tasksData);
        }
      }
    }

    loadTasks();
  }, [selectedCustomer, supabase]);

  const startTracking = () => {
    setStartTime(new Date());
    setIsTracking(true);
  };

  const stopTracking = async () => {
    if (!startTime || !employee) return;

    try {
      const endTime = new Date();
      
      const { error: insertError } = await supabase
        .from('time_entries')
        .insert({
          customer_id: selectedCustomer,
          employee_id: employee.id,
          task_id: selectedTask || null,
          description,
          start_time: startTime.toISOString(),
          end_time: endTime.toISOString(),
        });

      if (insertError) throw insertError;

      setIsTracking(false);
      setStartTime(null);
      setDescription('');
      router.refresh();
    } catch (err) {
      setError('Det oppstod en feil ved lagring av timeregistrering');
      console.error('Error saving time entry:', err);
    }
  };

  if (!employee) {
    return <div>Laster...</div>;
  }

  return (
    <div className="bg-white shadow-sm rounded-lg p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Timeregistrering</h3>

      {error && (
        <div className="mb-4 bg-red-50 text-red-600 p-3 rounded-md text-sm">
          {error}
        </div>
      )}

      <div className="space-y-4">
        <div>
          <label htmlFor="customer" className="block text-sm font-medium text-gray-700">
            Kunde
          </label>
          <select
            id="customer"
            value={selectedCustomer}
            onChange={(e) => setSelectedCustomer(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
            disabled={isTracking}
          >
            <option value="">Velg kunde</option>
            {customers.map((customer) => (
              <option key={customer.id} value={customer.id}>
                {customer.name}
              </option>
            ))}
          </select>
        </div>

        {selectedCustomer && (
          <div>
            <label htmlFor="task" className="block text-sm font-medium text-gray-700">
              Oppgave (valgfritt)
            </label>
            <select
              id="task"
              value={selectedTask}
              onChange={(e) => setSelectedTask(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              disabled={isTracking}
            >
              <option value="">Velg oppgave</option>
              {tasks.map((task) => (
                <option key={task.id} value={task.id}>
                  {task.title}
                </option>
              ))}
            </select>
          </div>
        )}

        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700">
            Beskrivelse
          </label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
            disabled={isTracking}
          />
        </div>

        <div className="flex justify-between items-center">
          <div>
            {isTracking && startTime && (
              <p className="text-sm text-gray-500">
                Startet: {startTime.toLocaleTimeString()}
              </p>
            )}
          </div>
          <div>
            {!isTracking ? (
              <button
                type="button"
                onClick={startTracking}
                disabled={!selectedCustomer || !description}
                className="btn-primary"
              >
                Start tidtaking
              </button>
            ) : (
              <button
                type="button"
                onClick={stopTracking}
                className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors duration-200"
              >
                Stopp tidtaking
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}