import TimeTracker from '@/components/TimeTracker';
import ExportTimeButton from '@/components/ExportTimeButton';
import { createServerComponentClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';
import { format } from 'date-fns';
import { nb } from 'date-fns/locale';

export default async function TimeTrackingPage() {
  const supabase = createServerComponentClient({ cookies });
  
  const { data: timeEntries } = await supabase
    .from('time_entries')
    .select(`
      *,
      customers (
        name
      ),
      tasks (
        title
      )
    `)
    .order('start_time', { ascending: false })
    .limit(10);

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold text-gray-900">Timeregistrering</h1>
          <ExportTimeButton />
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <TimeTracker />
          
          <div>
            <h2 className="text-lg font-medium text-gray-900 mb-4">Siste registreringer</h2>
            <div className="bg-white shadow-sm rounded-lg divide-y divide-gray-200">
              {timeEntries?.map((entry) => {
                const startTime = new Date(entry.start_time);
                const endTime = new Date(entry.end_time);
                const duration = (endTime.getTime() - startTime.getTime()) / (1000 * 60); // minutes

                return (
                  <div key={entry.id} className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-gray-900">
                          {entry.customers?.name}
                        </p>
                        {entry.tasks?.title && (
                          <p className="text-sm text-gray-500">
                            Oppgave: {entry.tasks.title}
                          </p>
                        )}
                        <p className="text-sm text-gray-600 mt-1">
                          {entry.description}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-900">
                          {format(startTime, 'PPP', { locale: nb })}
                        </p>
                        <p className="text-sm text-gray-500">
                          {Math.round(duration)} minutter
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}