'use client';

import { useEffect } from 'react';

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error('Application error:', error);
  }, [error]);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">
            Beklager, noe gikk galt
          </h2>
          <p className="text-gray-600 mb-4">
            Det oppstod en uventet feil. Vennligst prøv igjen.
          </p>
          <button
            onClick={reset}
            className="btn-primary"
          >
            Prøv igjen
          </button>
        </div>
      </div>
    </div>
  );
}