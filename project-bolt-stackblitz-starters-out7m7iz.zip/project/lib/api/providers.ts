import { AccountingProvider } from './types';

export const accountingProviders: AccountingProvider[] = [
  {
    id: 'fiken',
    name: 'Fiken',
    logo: '/images/providers/fiken.svg',
    description: 'Norsk regnskapsprogram for små og mellomstore bedrifter',
    isSupported: true,
    apiBaseUrl: 'https://api.fiken.no/api/v2',
    scopes: ['read', 'write'],
    authUrl: 'https://fiken.no/oauth/authorize',
    tokenUrl: 'https://fiken.no/oauth/token',
  },
  {
    id: 'tripletex',
    name: 'Tripletex',
    logo: '/images/providers/tripletex.svg',
    description: 'Komplett økonomisystem for bedrifter',
    isSupported: true,
    apiBaseUrl: 'https://api.tripletex.io',
    scopes: ['read', 'write'],
    authUrl: 'https://tripletex.no/execute/oauth2',
    tokenUrl: 'https://api.tripletex.io/v2/token/session',
  },
  {
    id: 'poweroffice',
    name: 'PowerOffice',
    logo: '/images/providers/poweroffice.svg',
    description: 'Skybasert økonomisystem',
    isSupported: false,
    apiBaseUrl: '',
    scopes: [],
    authUrl: '',
    tokenUrl: '',
  },
  {
    id: 'conta',
    name: 'Conta',
    logo: '/images/providers/conta.svg',
    description: 'Moderne regnskapsprogram',
    isSupported: true,
    apiBaseUrl: 'https://api.conta.no/v1',
    scopes: ['read', 'write'],
    authUrl: 'https://conta.no/oauth/authorize',
    tokenUrl: 'https://conta.no/oauth/token',
  },
];

export const getProvider = (id: string): AccountingProvider | undefined => {
  return accountingProviders.find(provider => provider.id === id);
};