export interface AccountingSystem {
  name: string;
  apiKey?: string;
  baseUrl: string;
  isConnected: boolean;
  accessToken?: string;
  refreshToken?: string;
  expiresAt?: Date;
}

export interface AccountingProvider {
  id: string;
  name: string;
  logo: string;
  description: string;
  isSupported: boolean;
  apiBaseUrl: string;
  scopes: string[];
  authUrl: string;
  tokenUrl: string;
}

export interface Customer {
  id: string;
  name: string;
  orgNumber: string;
  accountingSystem: string;
  lastSync?: Date;
  status: 'active' | 'inactive';
  accountingConnection?: {
    accessToken: string;
    refreshToken: string;
    expiresAt: Date;
  };
}

export interface AccountingData {
  balance: number;
  revenue: number;
  expenses: number;
  lastUpdated: Date;
  period: string;
}

export interface Employee {
  id: string;
  userId: string;
  name: string;
  email: string;
  role: 'admin' | 'accountant' | 'assistant';
  createdAt: Date;
}

export interface Task {
  id: string;
  customerId: string;
  type: 'vat' | 'salary' | 'yearend' | 'bookkeeping';
  title: string;
  dueDate: Date;
  status: 'pending' | 'in_progress' | 'completed';
  description: string;
  assignedTo?: string;
  assignedToEmployee?: Employee;
}

export interface TimeEntry {
  id: string;
  customerId: string;
  employeeId: string;
  taskId?: string;
  description: string;
  startTime: Date;
  endTime: Date;
  createdAt: Date;
  updatedAt: Date;
  customer?: Customer;
  employee?: Employee;
  task?: Task;
}

export interface AccountingIntegrationError extends Error {
  code: string;
  httpStatus?: number;
}