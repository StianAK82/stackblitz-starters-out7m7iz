import { FikenIntegration } from './fiken';
import { TripletexIntegration } from './tripletex';
import { ContaIntegration } from './conta';
import { BaseIntegration } from './base';
import { getProvider } from '../providers';

export function createIntegration(type: string, accessToken: string): BaseIntegration {
  const provider = getProvider(type);
  
  if (!provider) {
    throw new Error(`Unsupported accounting system: ${type}`);
  }

  switch (type) {
    case 'fiken':
      return new FikenIntegration(accessToken, provider.apiBaseUrl);
    case 'tripletex':
      return new TripletexIntegration(accessToken, provider.apiBaseUrl);
    case 'conta':
      return new ContaIntegration(accessToken, provider.apiBaseUrl);
    default:
      throw new Error(`No integration available for: ${type}`);
  }
}