import { BaseIntegration } from './base';

export class TripletexIntegration extends BaseIntegration {
  async getAccounts(): Promise<any> {
    return this.fetch('/v2/ledger/account');
  }

  async getTransactions(fromDate: Date, toDate: Date): Promise<any> {
    const params = new URLSearchParams({
      dateFrom: fromDate.toISOString(),
      dateTo: toDate.toISOString(),
    });

    return this.fetch(`/v2/ledger/posting?${params}`);
  }

  async getVatReturns(): Promise<any> {
    return this.fetch('/v2/ledger/vatType');
  }
}