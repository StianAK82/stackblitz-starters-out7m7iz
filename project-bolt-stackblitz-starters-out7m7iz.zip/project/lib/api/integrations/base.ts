import { AccountingIntegrationError } from '../types';

export abstract class BaseIntegration {
  protected accessToken: string;
  protected baseUrl: string;

  constructor(accessToken: string, baseUrl: string) {
    this.accessToken = accessToken;
    this.baseUrl = baseUrl;
  }

  protected async fetch<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers = {
      'Authorization': `Bearer ${this.accessToken}`,
      'Content-Type': 'application/json',
      ...options.headers,
    };

    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const error = new Error('API request failed') as AccountingIntegrationError;
      error.code = 'API_ERROR';
      error.httpStatus = response.status;
      throw error;
    }

    return response.json();
  }

  abstract getAccounts(): Promise<any>;
  abstract getTransactions(fromDate: Date, toDate: Date): Promise<any>;
  abstract getVatReturns(): Promise<any>;
}

export { BaseIntegration }