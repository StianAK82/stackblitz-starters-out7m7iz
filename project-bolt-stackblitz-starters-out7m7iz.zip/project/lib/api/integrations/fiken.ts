import { BaseIntegration } from './base';

export class FikenIntegration extends BaseIntegration {
  async getAccounts(): Promise<any> {
    return this.fetch('/accounts');
  }

  async getTransactions(fromDate: Date, toDate: Date): Promise<any> {
    const params = new URLSearchParams({
      fromDate: fromDate.toISOString().split('T')[0],
      toDate: toDate.toISOString().split('T')[0],
    });

    return this.fetch(`/transactions?${params}`);
  }

  async getVatReturns(): Promise<any> {
    return this.fetch('/vat-returns');
  }
}