/*
  # Create employees table and add employee assignment to tasks

  1. New Tables
    - `employees`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `name` (text, required)
      - `email` (text, required)
      - `role` (text, required)
      - `created_at` (timestamp)

  2. Changes to existing tables
    - Add `assigned_to` column to tasks table
    
  3. Security
    - Enable RLS on employees table
    - Add policies for authenticated users to:
      - Read employees in their organization
      - Create and update employees (admin only)
*/

-- Create employees table
CREATE TABLE IF NOT EXISTS employees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  name text NOT NULL,
  email text NOT NULL,
  role text NOT NULL CHECK (role IN ('admin', 'accountant', 'assistant')),
  created_at timestamptz DEFAULT now()
);

-- Add assigned_to column to tasks
ALTER TABLE tasks 
ADD COLUMN IF NOT EXISTS assigned_to uuid REFERENCES employees(id);

-- Enable RLS
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;

-- Policies for employees table
CREATE POLICY "Users can read employees"
  ON employees
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can create employees"
  ON employees
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM employees
      WHERE user_id = auth.uid()
      AND role = 'admin'
    )
  );

CREATE POLICY "Admins can update employees"
  ON employees
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM employees
      WHERE user_id = auth.uid()
      AND role = 'admin'
    )
  );