/*
  # Create client access table and policies

  1. New Tables
    - `client_access`
      - `id` (uuid, primary key)
      - `employee_id` (uuid, foreign key to employees)
      - `customer_id` (uuid, foreign key to customers)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on client_access table
    - Add policies for:
      - Admins can manage all access
      - Employees can only read their own access
*/

CREATE TABLE IF NOT EXISTS client_access (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid REFERENCES employees(id) ON DELETE CASCADE NOT NULL,
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(employee_id, customer_id)
);

ALTER TABLE client_access ENABLE ROW LEVEL SECURITY;

-- Policies for client_access
CREATE POLICY "Admins can manage client access"
  ON client_access
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM employees
      WHERE user_id = auth.uid()
      AND role = 'admin'
    )
  );

CREATE POLICY "Employees can read own access"
  ON client_access
  FOR SELECT
  TO authenticated
  USING (
    employee_id IN (
      SELECT id FROM employees
      WHERE user_id = auth.uid()
    )
  );

-- Update customers policy to check client_access
CREATE POLICY "Users can only access assigned clients"
  ON customers
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM client_access ca
      JOIN employees e ON e.id = ca.employee_id
      WHERE e.user_id = auth.uid()
      AND ca.customer_id = customers.id
    )
    OR EXISTS (
      SELECT 1 FROM employees
      WHERE user_id = auth.uid()
      AND role = 'admin'
    )
  );